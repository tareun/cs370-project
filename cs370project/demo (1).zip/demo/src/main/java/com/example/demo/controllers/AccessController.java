package com.example.demo.controllers;

import com.example.demo.Credentials;
import com.example.demo.GetArtist;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/")
public class AccessController
{
    @GetMapping("/token")
    public String getAccessToken()
    {
        String accessToken = Credentials.getAccessToken();

        if(accessToken != null)
        {
            String artistID = "7n2Ycct7Beij7Dj7meI4X0";
            String artistName = GetArtist.getArtistInfo(accessToken,artistID);
            return artistName;
        }
        else
        {
            return "Failed";
        }
        //return "Hello guys";
        //return Credentials.getAccessToken();
    }
}
