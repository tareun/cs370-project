package com.example.demo;

import se.michaelthelin.spotify.SpotifyApi;
import se.michaelthelin.spotify.exceptions.SpotifyWebApiException;
import se.michaelthelin.spotify.model_objects.specification.Artist;
import org.apache.hc.core5.http.ParseException;

import java.io.IOException;

public class GetArtistExample {
    public static void getArtistInfo(String accessToken, String artistId) {
        SpotifyApi spotifyApi = new SpotifyApi.Builder()
                .setAccessToken(accessToken)
                .build();

        try {
            Artist artist = spotifyApi.getArtist(artistId).build().execute(); // Fetch information about the specified artist

            // Display retrieved artist information
            System.out.println("Artist Name: " + artist.getName());
            // Other information can be accessed and used similarly
        } catch (IOException | SpotifyWebApiException | ParseException e) {
            System.out.println("Error getting artist information: " + e.getMessage());
        }
    }
}
